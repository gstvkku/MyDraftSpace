package io.codeforall.bootcamp.Exceptions;

public class FileException extends Exception {
    public FileException(String str) {
        super(str);
    }
}
