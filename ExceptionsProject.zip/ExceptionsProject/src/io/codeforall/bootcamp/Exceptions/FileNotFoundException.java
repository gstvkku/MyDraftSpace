package io.codeforall.bootcamp.Exceptions;

public class FileNotFoundException extends FileException{
    public FileNotFoundException(String str) {
        super(str);
    }
}
