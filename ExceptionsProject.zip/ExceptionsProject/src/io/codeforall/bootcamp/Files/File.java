package io.codeforall.bootcamp.Files;

public class File {
    private final String fileName;
    public File(String name) {
        this.fileName = name;
    }

    public String getFileName() {
        return fileName;
    }
}
